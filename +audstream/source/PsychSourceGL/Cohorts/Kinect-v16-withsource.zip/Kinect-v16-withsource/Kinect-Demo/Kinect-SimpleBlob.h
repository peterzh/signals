#pragma once
#include <vector>

namespace BlobSpace
{
	struct BlobCoordinate
	{
		unsigned int x, y;
		void * data;
	};

	struct BlobLineBlob
	{
		unsigned int min, max;
		unsigned int blobId;

		bool attached;
	};

	struct Blob
	{
		//unsigned int blobId;
		BlobCoordinate min, max;
		BlobCoordinate center;
		int size;
	};
	
	struct BlobFrame
	{
		int width, height;
		float *imageData;
	};

	extern void DetectBlobs(BlobFrame* frame, std::vector<Blob> *OutBlobs);
	
};

