#include "Kinect-SimpleBlob.h"

#include <map>

namespace BlobSpace
{
	bool inRange(float val)
	{
		if (val > 10 && val < 100) return true;
		return false;
	};


	void DetectBlobs(BlobFrame* frame, std::vector<Blob> *OutBlobs)
	{

		int blobCounter = 0;
		std::map<unsigned int, Blob> blobs;

		float threshold = 235;


		std::vector< std::vector<BlobLineBlob> > imgData(frame->width);

		for(int row = 0; row < frame->height; ++row)
		{

			for(int column = 0; column < frame->width; ++column)
			{

				//unsigned char byte = (unsigned char) imgStream.get();
				float val = frame->imageData[(row*frame->width)+ column];

				if(inRange(val))
				{
					int start = column;

					for(;inRange(val); val = frame->imageData[(row*frame->width)+ column], ++column);

					int stop = column-1;
					BlobLineBlob lineBlobData = {start, stop, blobCounter, false};

					imgData[row].push_back(lineBlobData);
					blobCounter++;
				}
			}
		}

		/* Check lineBlobs for a touching lineblob on the next row */

		for(unsigned int row = 0; row < imgData.size(); ++row)
		{

			for(unsigned int entryLine1 = 0; entryLine1 < imgData[row].size(); ++entryLine1)
			{

				for(unsigned int entryLine2 = 0; entryLine2 < imgData[row+1].size(); ++entryLine2)
				{

					if(!((imgData[row][entryLine1].max < imgData[row+1][entryLine2].min) || (imgData[row][entryLine1].min > imgData[row+1][entryLine2].max)))
					{

						if(imgData[row+1][entryLine2].attached == false)
						{

							imgData[row+1][entryLine2].blobId = imgData[row][entryLine1].blobId;

							imgData[row+1][entryLine2].attached = true;
						}
						else

						{
							imgData[row][entryLine1].blobId = imgData[row+1][entryLine2].blobId;

							imgData[row][entryLine1].attached = true;
						}
					}
				}
			}
		}

		// Sort and group blobs

		for(int row = 0; row < imgData.size(); ++row)
		{

			for(int entry = 0; entry < imgData[row].size(); ++entry)
			{

				if(blobs.find(imgData[row][entry].blobId) == blobs.end()) // Blob does not exist yet

				{
					Blob blobData = {{imgData[row][entry].min, row}, {imgData[row][entry].max, row}, {0,0}};

					blobs[imgData[row][entry].blobId] = blobData;
				}
				else

				{
					if(imgData[row][entry].min < blobs[imgData[row][entry].blobId].min.x)

						blobs[imgData[row][entry].blobId].min.x = imgData[row][entry].min;

					else if(imgData[row][entry].max > blobs[imgData[row][entry].blobId].max.x)

						blobs[imgData[row][entry].blobId].max.x = imgData[row][entry].max;

					if(row < blobs[imgData[row][entry].blobId].min.y)

						blobs[imgData[row][entry].blobId].min.y = row;

					else if(row > blobs[imgData[row][entry].blobId].max.y)

						blobs[imgData[row][entry].blobId].max.y = row;
				}
			}
		}

		// Calculate center
		for(std::map<unsigned int, Blob>::iterator i = blobs.begin(); i != blobs.end(); ++i)
		{
			(*i).second.center.x = (*i).second.min.x + ((*i).second.max.x - (*i).second.min.x) / 2;
			(*i).second.center.y = (*i).second.min.y + ((*i).second.max.y - (*i).second.min.y) / 2;

			(*i).second.size = ((*i).second.max.x - (*i).second.min.x) * ((*i).second.max.y - (*i).second.min.y);					
			OutBlobs->push_back(i->second);
		}
	}

};