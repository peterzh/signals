#include "../Kinect-win32.h"
#include "../Kinect-Utility.h"

#include <conio.h>
#include <windows.h>
#include <math.h>


//#define SENDOSC 

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#include "Glee-5.4/GLee.h"
#include <gl/glu.h>

#define BLOBDIV 4
#define MAXPARTICLE 15000

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "winmm.lib")

#ifdef SENDOSC
#include "Kinect-SimpleBlob.h"
using namespace BlobSpace;
#include "oscpack/osc/OscOutboundPacketStream.h"
#include "oscpack/ip/UdpSocket.h"
UdpTransmitSocket *gTransmitSocket;
#endif

#define HISTDIV 32
#define HISTLEN (2048/HISTDIV)

#include "OpenCV/cv.h"


// 1-neighbors of pixel.
int nays8(IplImage *im, int r, int c) {
	CvScalar pixel;
	int blue, k = 0, i, j;

  for (i = r-1; i <= r+1; i++) 
		for (j = c-1; j <= c+1; j++) 
			if (i != r || c != j) {
				pixel = cvGet2D(im, i, j);
				blue = pixel.val[0];
				if (blue >= 1)
					k++;
			}

	return k;
} 
int connectivity(IplImage *im, int r, int c) {
	int N = 0, b1, b2;
	CvScalar pixel;

	pixel = cvGet2D(im, r, c+1);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r-1, c+1);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0) 
		N++;

	pixel = cvGet2D(im, r-1, c+1);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r-1, c);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0)
		N++;

	pixel = cvGet2D(im, r-1, c);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r-1, c-1);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0)
		N++;

	pixel = cvGet2D(im, r-1, c-1);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r, c-1);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0)
		N++;

	pixel = cvGet2D(im, r, c-1);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r+1, c-1);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0)
		N++;

	pixel = cvGet2D(im, r+1, c-1);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r+1, c);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0)
		N++;

	pixel = cvGet2D(im, r+1, c);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r+1, c+1);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0)
		N++;

	pixel = cvGet2D(im, r+1, c+1);
	b1 = pixel.val[0];
	pixel = cvGet2D(im, r, c+1);
	b2 = pixel.val[0];
	if (b1 >= 1 && b2 == 0)
		N++;

	return N;
}

void deleteCB(IplImage *im, IplImage *tmp) {
	int w, h, blue, i, j;
	CvScalar pixel;

	w = im->width;
	h = im->height;

	for (i = 1; i < h-1; i++)
		for (int j = 1; j < w-1; j++) {
			pixel = cvGet2D(tmp, i, j);
			blue = pixel.val[0];
			if (blue == 1) {
				pixel.val[0] = 0;
				cvSet2D(im, i, j, pixel);
				cvSet2D(tmp, i, j, pixel);
			}
		}
}
#define NORTH 1
#define SOUTH 3
void stair(IplImage *im, IplImage *tmp, int dir) {
	int i, j, b1, b2, b3, b4, b5, b6, b7, b8, b9, w, h;
	CvScalar pixel;
	int N, S, E, W, NE, NW, SE, SW, C;

	w = im->width;
	h = im->height;

	if (dir == NORTH)
		for (i = 1; i < h-1; i++)
			for (j = 1; j < w-1; j++) {
				pixel = cvGet2D(im, i-1, j-1);
				b1 = pixel.val[0];
				pixel = cvGet2D(im, i-1, j);
				b2 = pixel.val[0];
				pixel = cvGet2D(im, i-1, j+1);
				b3 = pixel.val[0];
				pixel = cvGet2D(im, i, j-1);
				b4 = pixel.val[0];
				pixel = cvGet2D(im, i, j);
				b5 = pixel.val[0];
				pixel = cvGet2D(im, i, j+1);
				b6 = pixel.val[0];
				pixel = cvGet2D(im, i+1, j-1);
				b7 = pixel.val[0];
				pixel = cvGet2D(im, i+1, j);
				b8 = pixel.val[0];
				pixel = cvGet2D(im, i+1, j+1);
				b9 = pixel.val[0];
				if (b1 == 1)
					NW = 1;
				else
					NW = 0;
				if (b2 == 1)
					N = 1;
				else
					N = 0;
				if (b3 == 1)
					NE = 1;
				else
					NE = 0;
				if (b4 == 1)
					W = 1;
				else
					W = 0;
				if (b5 == 1)
					C = 1;
				else
					C = 0;
				if (b6 == 1)
					E = 1;
				else
					E = 0;
				if (b7 == 1)
					SW = 1;
				else
					SW = 0;
				if (b8 == 1)
					S = 1;
				else
					S = 0;
				if (b9 == 1)
					SE = 1;
				else
					SE = 0;

				if (dir == NORTH) {
					if (C && !(N && ((E && !NE && !SW && (!W || !S)) || 
						 (W && !NW && !SE && (!E || !S))))) {
						pixel.val[0] = 0;
						cvSet2D(tmp, i, j, pixel);
					} else {
						pixel.val[0] = 1;
						cvSet2D(tmp, i, j, pixel);
					}
				} else if (dir == SOUTH) {
					if (C && !(S && ((E && !SE && !NW && (!W || !N)) || 
						 (W && !SW && !NE && (!E || !N))))) {
						pixel.val[0] = 0;
						cvSet2D(tmp, i, j, pixel);
					} else {
						pixel.val[0] = 1;
						cvSet2D(tmp, i, j, pixel);
					}
				}
			}
}

// Zhang-Suen algorithm.
void skeletonize(IplImage *im) {
	int janelaAH[][2] = {
		{1, 0}, {0, -1}, {-1, 0}, {0, 1}
	};
	int janelaH[][2] = {
		{0, -1}, {1, 0}, {0, 1}, {-1, 0}
	};
	int aBlue[6];
	int w, h, i, v, j, k, blue, lin, col, iJanela, again = 1;
	CvScalar pixel, pixOut;	
	IplImage *tmp = 0;
	
	w = im->width;
	h = im->height;
	tmp = cvCreateImage(cvGetSize(im), IPL_DEPTH_8U, 1);
	
  for (i = 0; i < h; i++) {
		for (j = 0; j < w; j++) { 
			pixel = cvGet2D(im, i, j);
			blue = pixel.val[0];
			if (blue > 0)
				pixel.val[0] = 0;
			else
				pixel.val[0] = 1;
			cvSet2D(im, i, j, pixel);
			pixOut.val[0] = 0;
			cvSet2D(tmp, i, j, pixOut);
		}
	}

	while (again) {
		again = 0;
  	for (i = 1; i < h-1; i++) 
			for (j = 1; j < w-1; j++) { 
				pixel = cvGet2D(im, i, j);
				blue = pixel.val[0];
				if (blue != 1)
					continue;
				k = nays8(im, i, j);
				iJanela = 0;
				if ((k >= 2 && k <= 6) && connectivity(im, i, j) == 1) {
					for (v = 0; v < 6; v++) {
						col = j + janelaAH[iJanela][0];
						lin = i + janelaAH[iJanela][1];
						pixel = cvGet2D(im, lin, col);
						aBlue[v] = pixel.val[0];
						iJanela++;
						if (v == 2) 
							iJanela = 1;
					}
					if (aBlue[0]*aBlue[1]*aBlue[2] == 0 &&
							aBlue[3]*aBlue[4]*aBlue[5] == 0) {
						pixOut.val[0] = 1;
						cvSet2D(tmp, i, j, pixOut);
						again = 1;
					}
				}		// if ((k >= 2...
			}		// for (j = 1;...

			deleteCB(im, tmp);
			if (!again)
				break;

  	for (i = 1; i < h-1; i++) 
			for (j = 1; j < w-1; j++) { 
				pixel = cvGet2D(im, i, j);
				blue = pixel.val[0];
				if (blue != 1)
					continue;
				k = nays8(im, i, j);
				iJanela = 0;
				if ((k >= 2 && k <= 6) && connectivity(im, i, j) == 1) {
					for (v = 0; v < 6; v++) {
						col = j + janelaH[iJanela][0];
						lin = i + janelaH[iJanela][1];
						pixel = cvGet2D(im, lin, col);
						aBlue[v] = pixel.val[0];
						iJanela++;
						if (v == 2) 
							iJanela = 1;
					}
					if (aBlue[0]*aBlue[1]*aBlue[2] == 0 &&
							aBlue[3]*aBlue[4]*aBlue[5] == 0) {
						pixOut.val[0] = 1;
						cvSet2D(tmp, i, j, pixOut);
						again = 1;
					}
				}		// if ((k >= 2...
			}		// for (j = 1;...

		deleteCB(im, tmp);
	}		// while

	stair(im, tmp, NORTH);
	deleteCB(im, tmp);
	stair(im, tmp, SOUTH);
	deleteCB(im, tmp);

  for (i = 1; i < h-1; i++) 
		for (j = 1; j < w-1; j++) { 
			pixel = cvGet2D(im, i, j);
			blue = pixel.val[0];
			if (blue > 0)
				pixel.val[0] = 0;
			else
				pixel.val[0] = 255;
			cvSet2D(im, i, j, pixel);
		}
}		// End skeletonize


template <typename T> 
T HistogramFromZ(float Z)
{
	float i = (Z-40.0f) * ((HISTLEN)/300.0f);
	return (T)__min(HISTLEN, __max(0,i));
};

float ZFromHistogram(int Histo)
{
	return (float)(Histo-0.5) / ((HISTLEN)/300.0f) + 40;
};

template <typename T> class VBO
{
public:
	VBO(int maxsize)
	{
		maxsize = __max(1,maxsize);
		T *Initial = new T[maxsize];

		glGenBuffers(1, &mVBO);
		glBindBuffer(GL_ARRAY_BUFFER, mVBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(T)*maxsize, NULL, GL_STREAM_DRAW_ARB);
		delete [] Initial;
	};

	void Render(int Do)
	{
		glBindBuffer(GL_ARRAY_BUFFER_ARB, mVBO);

		glEnableClientState(GL_VERTEX_ARRAY);
		//		glEnableClientState(GL_COLOR_ARRAY);

		glVertexPointer(3, GL_FLOAT, sizeof(T), 0);  
		//		glColorPointer(3, GL_UNSIGNED_BYTE, sizeof(Vertex), (GLvoid*)20);  
		glDrawArrays(GL_POINTS, 0, Do);

		glDisableClientState(GL_VERTEX_ARRAY);
		//		glDisableClientState(GL_COLOR_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER_ARB, 0);

	}
	void Upload(T *Verts, int NumVerts)
	{
		glBindBuffer(GL_ARRAY_BUFFER_ARB, mVBO);
		float *buf = (float*)glMapBuffer(GL_ARRAY_BUFFER_ARB, GL_WRITE_ONLY);
		if (buf)
		{
			memcpy(buf, Verts, sizeof(T)*NumVerts);
			glUnmapBuffer(GL_ARRAY_BUFFER_ARB);
		};

		glBindBuffer(GL_ARRAY_BUFFER_ARB, 0);
	}
	GLuint mVBO;
};

template <typename T> class GridVBOSet
{
public:
	GridVBOSet(int w, int h, T* Vertices)
	{
		mRowSize = sizeof(T) * w;

		int MaxVerticesInVBO;
		glGetIntegerv(GL_MAX_ELEMENTS_VERTICES, &MaxVerticesInVBO);
		//ATI FIX!
		if (MaxVerticesInVBO > 4000000) MaxVerticesInVBO = 500000; // this should be low enough
		mRowsPerVBO = (int)floor((float)MaxVerticesInVBO/(float)mRowSize);
		mRows = h;
		mCols = w;
		mVBOCount =1+( mRows /mRowsPerVBO);
		if (MaxVerticesInVBO >= w*h)
		{
			mVBOCount= 1;
			mVerticesPerVBO = w*h;
		}
		else
		{
			mVerticesPerVBO= mRowsPerVBO*mCols;
		}
		mRowVBOs = new int [h];
		for (int j = 0;j<mVBOCount;j++)
		{
			VBO<T> *vbo = new VBO<T>(mVerticesPerVBO);
			mVBOs.push_back(vbo);
		};
		glGenBuffers(1, &mIndicesBuffer);

		glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, mIndicesBuffer);
		glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, w*h*sizeof(int), NULL, GL_STREAM_DRAW_ARB);
		glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);

	};
	GLuint mIndicesBuffer;
	virtual ~GridVBOSet()
	{
		for (unsigned int i =0;i<mVBOs.size();i++)
		{
			delete mVBOs[i];
		};
		mVBOs.clear();
		if (mRowVBOs) delete [] mRowVBOs;
	};

	void Upload(T *Vertices, int Count)
	{
		int Current = 0;
		while (Count>0)
		{
			int Do = __min(Count, mVerticesPerVBO);
			mVBOs[Current]->Upload(Vertices + Current * mVerticesPerVBO, Do);
			Count -= Do;
			Current++;
		};
	};

	void Render(int VertexCount)
	{
		int Current = 0;
		while (VertexCount>0)
		{
			int Do = __min(VertexCount, mVerticesPerVBO);
			mVBOs[Current]->Render(Do);
			VertexCount -= Do;
			Current++;
		};
	};

	std::vector<VBO<T> *> mVBOs;
	int mRowSize;
	int mCols;
	int mRows;
	int mVBOCount;
	int mRowsPerVBO;
	int mVerticesPerVBO;
	int mDataSize;
	int *mRowVBOs;
};


unsigned int SetupShaderProgram(const char *vsource, const char *fsource)
{

	int W = 0;
	char text[10000];

	GLenum vshader;

	vshader = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
	glShaderSourceARB(vshader, 1, &vsource, NULL);
	glGetInfoLogARB(vshader, 10000, &W, text);
	if (W>0) printf("fragment shader compiler error: %s\n", text);

	GLenum fshader;
	fshader = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);
	glShaderSourceARB(fshader, 1, &fsource, NULL);
	glGetInfoLogARB(fshader, 10000, &W, text);
	if (W>0) printf("fragment shader compiler error: %s\n", text);

	GLenum program = glCreateProgramObjectARB();

	glCompileShaderARB(fshader);
	glGetInfoLogARB(fshader, 10000, &W, text);
	if (W>0) printf("fragment shader compiler error: %s\n", text);

	glCompileShaderARB(vshader);
	glGetInfoLogARB(vshader, 10000, &W, text);
	if (W>0) printf("fragment shader compiler error: %s\n", text);

	glAttachObjectARB(program, fshader);
	glGetInfoLogARB(fshader, 10000, &W, text);
	if (W>0) printf("fragment shader compiler error: %s\n", text);
	glAttachObjectARB(program, vshader);
	glGetInfoLogARB(vshader, 10000, &W, text);
	if (W>0) printf("fragment shader compiler error: %s\n", text);

	glLinkProgramARB(program);
	glGetInfoLogARB(program, 10000, &W, text);
	if (W>0) printf("fragment shader compiler error: %s\n", text);
	return program;
};


unsigned int SetupShaderProgramFromFiles(const char *vsourcefile, const char *fsourcefile)
{
	printf("trying to load %s and %s\n",vsourcefile,fsourcefile);
	FILE *F = fopen(vsourcefile,"rb+");
	FILE *F2 = fopen(fsourcefile,"rb+");
	if (F && F2)
	{
		fseek (F, 0, SEEK_END);
		int size=ftell (F);
		fseek(F,0,SEEK_SET);
		char *vsource = new char[size+1];
		fread(vsource, 1, size, F);
		vsource[size] = 0;
		fclose(F);

		fseek (F2, 0, SEEK_END);
		size=ftell (F2);
		fseek(F2,0,SEEK_SET);
		char *fsource = new char[size+1];
		fread(fsource, 1, size, F2);
		fsource[size] = 0;
		fclose(F2);
		unsigned int ret = SetupShaderProgram(vsource, fsource);

		delete [] fsource;
		delete [] vsource;
		return ret;
	}
	else
	{
		if (F) fclose(F);
		if (F2) fclose(F2);
		return 0;
	};

}
class SimpleTexture
{
public:
	SimpleTexture()
	{
		glGenTextures(1, &mTex);
		glBindTexture(GL_TEXTURE_2D, mTex);
		glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );


		unsigned char *blankimage = new unsigned char[512*512*3];
		for (int i= 0;i<512*512;i++)
		{
			int x = (i/32);
			int y = (x/32)/32;
			x%= (1024/32);
			unsigned char check = ((x+y)%2 ==1)?0xff:0;
			blankimage[i*3+0] = check;
			blankimage[i*3+1] = check;
			blankimage[i*3+2] = check;
		};


		glTexImage2D(GL_TEXTURE_2D, 0,GL_RGB, 512,512, 0,GL_RGB, GL_UNSIGNED_BYTE, blankimage);
		delete [] blankimage;
		glBindTexture(GL_TEXTURE_2D, 0);
	};

	void Bind(int texunit = 0)
	{
		glBindTexture(GL_TEXTURE_2D, mTex);
	}

	void Upload(int w, int h, unsigned	char*data)					
	{
		glBindTexture(GL_TEXTURE_2D, mTex);

		glTexSubImage2D(GL_TEXTURE_2D, 0,0,0,w,h, GL_RGB,GL_UNSIGNED_BYTE, data);

		glBindTexture(GL_TEXTURE_2D, 0);
	};
	unsigned int mTex;
};

class Vertex
{
public:
	Vertex()
	{

	};

	Vertex(float _X, float _Y, float _Z)
	{
		x = _X;
		y = _Y;
		z = _Z;

	};
	float x,y,z; // position
	//float u,v; // texture coord 1

	void DepthToWorld()
	{
		Kinect::KinectDepthToWorld(x,y,z);;
	};
};

class Particle
{
public:
	Vertex mPosition;
	Kinect::V4ub mColor;
	bool mActive;
	float mAge;
	void Reset()
	{
		mAge = 0;
		mActive = true;
		mColor.x = 255;
	};
	void Update(float dt)
	{
		mPosition.y += dt*5;
		mAge+=dt;
		mColor.y = (unsigned char)(__max(1.0-mAge/4.0f,0)*255.0f);
		mColor.z = (unsigned char)(__max(1.0-mAge/2.0f,0)*255.0f);;
		mColor.w =(unsigned char)(__max(1.0-mAge/6.0f,0)*255.0f);
		if (mColor.w == 0) mActive = false;
	};

	void Render()
	{
		glColor4ubv(&mColor.x);
		glVertex3fv(&mPosition.x);
	};
};

class KinectTest: public Kinect::KinectListener
{
public:

	unsigned short mGammaMap[2048];
	unsigned char DepthColor[640*480*3];
	float DepthAverage[640*480];

	float mDepthBuffer[640*480];
	float mMaxDepthBuffer[640*480];
	unsigned short mBitDepthBuffer[640*480];

	Kinect::Kinect *mKinect;
	float mMotorPosition;
	int mLedMode;


	void SetupWindow();
	void Run();

	void RenderFrustum(float x, float y,float z);

	float mLastValidAcceleroX;
	float mLastValidAcceleroY;
	float mLastValidAcceleroZ;

	float mAvgDownX;
	float mAvgDownY;
	float mAvgDownZ;
	int mLastDepthFrameCounter;
	int mDepthFrameCounter; 
	int mLastColorFrameCounter;
	int mColorFrameCounter; 
	int mMotorRested;

#ifdef SENDOSC
	std::vector<BlobSpace::Blob> mBlobs;

#endif

#define BLOBW 640/BLOBDIV
#define BLOBH 480/BLOBDIV

	float mOldBFrame[480/BLOBDIV][640/BLOBDIV];
	float mBFrame[480/BLOBDIV][640/BLOBDIV];
	float mDFrame[480/BLOBDIV][640/BLOBDIV];

	float mKeyedFrame[BLOBH][BLOBW];

#define MAXKEYED 4
	int mKeyedHist[HISTLEN];

	float mKeyedHistD1[HISTLEN];
	float mKeyedHistD2[HISTLEN];
	std::vector<Kinect::V2i> mKeyedHistRanges;
	std::vector<Kinect::V4f> mFoundContours;
	std::vector<Kinect::V2f> mFoundContoursYExtents;
	std::vector<bool> mRenderFoundContours;
	void SetupVertex(int &idx, float x,float y,float z, unsigned char r, unsigned char g, unsigned char b);

	Particle mParticles[MAXPARTICLE];
	int mLastParticleAssigned ;

	SimpleTexture *mKeyedThings[MAXKEYED];
	SimpleTexture *mTopHistogram;
	int mTopHist[BLOBW][HISTLEN];

	void CalculateContours()
	{
		
		for (unsigned int i =0 ;i<mFoundContours.size();i++)
		{
			Vertex V1(mFoundContours[i].x,mFoundContoursYExtents[i].x, mFoundContours[i].z );
			Vertex V2(mFoundContours[i].y,mFoundContoursYExtents[i].y, mFoundContours[i].w);
			float MidZ = (V1.z + V2.z)/2.0;
			bool draw = false;
			for (int j =0;j<mKeyedHistRanges.size();j++)
			{
				if (V1.z >= mKeyedHistRanges[j].x && V2.z<= mKeyedHistRanges[j].y)
				{
					mRenderFoundContours[i] = true;
				}
			}
		};

		int activetex =0;

		for (int j = 0;j<mRenderFoundContours.size() && activetex<MAXKEYED;j++)
		{
			if (mRenderFoundContours[j])

			{

				glEnable(GL_TEXTURE_2D);
				unsigned char Keyed[BLOBH][BLOBW*3];
				unsigned char *Keyed8 = new unsigned char [BLOBH*BLOBW];
				float MinBoundary = ::ZFromHistogram(mFoundContours[j].w-2);
				float MaxBoundary = ::ZFromHistogram(mFoundContours[j].z+2);
				int MinX= mFoundContours[j].x;
				int MaxX= mFoundContours[j].y;
				unsigned char *P = &Keyed[0][0];
				unsigned char *P2 = Keyed8;
				float *src = &mBFrame[0][0];
				float Mult = 200/(MaxBoundary-MinBoundary);
				int localx=0 ;
				for (int j =0 ;j< BLOBW*BLOBH;j++)
				{


					float V = *src;
					if (V>=MinBoundary && V<=MaxBoundary && localx>=MinX && localx<=MaxX)
					{
						unsigned char G = (unsigned char )((V-MinBoundary)*Mult);
						G= ~G;
						*P++ =G;
						*P++ =G;
						*P++ =G;
						*P2++ = G;
					}
					else
					{
						*P++ =0;
						*P++ =0;
						*P++ =0;
						*P2++ = 0;
					}

					localx++;
					if (localx == BLOBW) localx = 0;

					src++;

				};

				CvMemStorage* storage = cvCreateMemStorage(0);
				IplImage* img = cvCreateImage(cvSize(BLOBW,BLOBH), 8, 1 );
				cvZero( img );

				for (int x= 0;x<BLOBW;x++) 
				{
					for (int y =0;y<BLOBH;y++)
					{
						((uchar *)(img->imageData + y*img->widthStep))[x] = Keyed8[x+y*BLOBW];
					}
				}

				CvSeq* contours = 0;
				//cvSmooth(img, img);
				//cvSmooth(img, img);

				cvThreshold(img, img, 59,255,CV_THRESH_BINARY);
				//cvErode(img,img, 0,1);
				cvDilate(img, img, 0, 3);
				cvCanny(img, img, 20,100,3);
				cvDilate(img, img, 0, 1);
				


//				skeletonize(img);

				cvFindContours( img, storage, &contours, sizeof(CvContour), CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0) );

				for (int x= 0;x<BLOBW;x++) 
				{
					for (int y =0;y<BLOBH;y++)
					{
						Keyed8[x+y*BLOBW] =  ((unsigned char *)(img->imageData + y*img->widthStep))[x];
					}
				}


				
				P = Keyed8;
				//P = (unsigned char *)img->imageData;
				P2 = &Keyed[0][0];
				for (int j =0 ;j< BLOBH*BLOBW;j++)
				{
					unsigned char V = *P++;
					*P2++ = V;
					*P2++ = V;
					*P2++ = V;
				};

				mFoundContoursYExtents[j].x = 100000;
				mFoundContoursYExtents[j].y = -100000;
				while (contours)
				{
					Kinect::V4f Exts;
					Exts.x = 100000;
					Exts.y = -100000;
					Exts.z = -100000;
					Exts.w = 100000;

					for(int i=0;i<contours->total;i++)
					{
						CvPoint *point =  (CvPoint *)CV_GET_SEQ_ELEM(CvPoint,contours,i);
						if (point->y > mFoundContoursYExtents[j].y) mFoundContoursYExtents[j].y = point->y;
						if (point->y < mFoundContoursYExtents[j].x) mFoundContoursYExtents[j].x = point->y;
						Keyed[point->y][point->x*3 ] = 255;
						Keyed[point->y][point->x*3 +1] = 0;
						Keyed[point->y][point->x*3 +2] = 0;
					};

					contours = contours->h_next;
				};

				cvReleaseMemStorage( &storage );
				cvReleaseImage( &img );

				mKeyedThings[activetex]->Upload(BLOBW, BLOBH, &Keyed[0][0]);
				activetex++;
			}
		}
		
	};
	void CalculateTopHistogram()
	{

		unsigned char *Keyed = new unsigned char[BLOBW*(HISTLEN)*3];
		unsigned char *Keyed8 = new unsigned char[BLOBW*(HISTLEN)*3];
		unsigned char *P = Keyed8;
		int *src = &mTopHist[0][0];
		float Mult = 20;
		int yy = 0;
		int xx = 0;
		for (int j =0 ;j< (HISTLEN)*BLOBW;j++)
		{

			float V = mTopHist[xx][yy];
			xx++;
			if (xx>=160){yy++;xx=0;};
			unsigned char G = (unsigned char)(__min(255, V*Mult));
			*P++ = G;

		};

		CvMemStorage* storage = cvCreateMemStorage(0);
		IplImage* img = cvCreateImage(cvSize(BLOBW,HISTLEN), 8, 1 );
		cvZero( img );
		IplImage* img2 = cvCreateImage(cvSize(BLOBW,HISTLEN), 8, 1 );
		cvZero( img2 );
		for (int x= 0;x<BLOBW;x++) 
		{
			for (int y =0;y<HISTLEN;y++)
			{
				((uchar *)(img->imageData + y*img->widthStep))[x] = Keyed8[x+y*BLOBW];
			}
		}

		CvSeq* contours = 0;
		//cvSmooth(img, img);
		//cvSmooth(img, img);

		cvThreshold(img, img, 59,255,CV_THRESH_BINARY);
		//cvErode(img,img, 0,1);
		cvDilate(img, img, 0, 3);
		cvCanny(img, img2, 20,100,3);
		cvFindContours( img2, storage, &contours, sizeof(CvContour), CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0) );

		for (int x= 0;x<BLOBW;x++) 
		{
			for (int y =0;y<HISTLEN;y++)
			{
				Keyed8[x+y*BLOBW] =  ((uchar *)(img->imageData + y*img->widthStep))[x];
			}
		}


		P = Keyed8;
		//P = (unsigned char *)img->imageData;
		unsigned char *P2 = Keyed;
		for (int j =0 ;j< (HISTLEN)*BLOBW;j++)
		{
			unsigned char V = *P++;
			*P2++ = V;
			*P2++ = V;
			*P2++ = V;
		};
		mFoundContours.clear();
		mRenderFoundContours.clear();
		mFoundContoursYExtents.clear();
		while (contours)
		{
			Kinect::V4f Exts;
			Exts.x = 100000;
			Exts.y = -100000;
			Exts.z = -100000;
			Exts.w = 100000;

			for(int i=0;i<contours->total;i++)
			{
				CvPoint *point =  (CvPoint *)CV_GET_SEQ_ELEM(CvPoint,contours,i);
				if (point->x > Exts.y) Exts.y = point->x;
				if (point->x < Exts.x) Exts.x = point->x;
				if (point->y > Exts.z) Exts.z = point->y;
				if (point->y < Exts.w) Exts.w = point->y;

				Keyed[(point->y * BLOBW + point->x)*3 ] = 255;
				Keyed[(point->y * BLOBW + point->x)*3 +1] = 0;
				Keyed[(point->y * BLOBW + point->x)*3 +2] = 0;
			};
			float dx = Exts.y-Exts.x;
			float dy = Exts.w-Exts.z;
			if (dx*dx+dy*dy > 15)
			{
				mFoundContours.push_back(Exts);
				mFoundContoursYExtents.push_back(Kinect::V2f(0,0));
				mRenderFoundContours.push_back(false);
			};
			contours = contours->h_next;
		};

		cvReleaseMemStorage( &storage );
		cvReleaseImage( &img );
		cvReleaseImage( &img2 );

		mTopHistogram->Upload(BLOBW, (HISTLEN),Keyed);
		delete [] Keyed;
		delete [] Keyed8;
	}


	// members for test display 3: (opengl output);
	HWND W3;
	HGLRC mGLContext ;
	float mTime;
	float mAngle;
	float mTilt;
	void InitGL();
	void DestroyGL();
	void DrawGL(float w, float h);
	void ActualRender();
	GLuint mDepthTexture;

	GLuint mColorTexture;



	GridVBOSet<Vertex> *mVBOGrid;

	std::vector<GLenum> mShaders;
	int mCurrentShader;

	int mColorMode;
	bool mKeyBackground;
	bool mEnableParticles;

	bool mEnableRefCube ;
	bool mEnableFrustum ;
	bool mStereo3d;

	Kinect::V3ub mRenderColor;
	Kinect::V3f mClearColor;
	Vertex mVertices[640*480];
	int mActualVertexCount;
	float mDistance;

	void DoGLChar(unsigned short KeyCode);

	void DoChar(unsigned short KeyCode)
	{
		switch (KeyCode)
		{
		case VK_LEFT:	mLedMode = (mLedMode + 1)%8; mKinect->SetLedMode(mLedMode); break;
		case VK_RIGHT:  mLedMode = (mLedMode + 8 - 1)%8; mKinect->SetLedMode(mLedMode); break;
		case VK_UP:  mMotorRested = 0;mMotorPosition = __min(1.0f, mMotorPosition + 0.05f); mKinect->SetMotorPosition(mMotorPosition);break;
		case VK_DOWN: mMotorRested = 0; mMotorPosition = __max(0, mMotorPosition - 0.05f); mKinect->SetMotorPosition(mMotorPosition);break;
		case VK_ESCAPE: PostQuitMessage(0);break;
		case VK_HOME: 
		case VK_SUBTRACT: mDistance+=0.1f;break;
		case VK_END:
		case VK_ADD: mDistance-=0.1f;break;

		case '1':
		case VK_NEXT: mCurrentShader = (mCurrentShader- 1 + mShaders.size())%mShaders.size();break;
		case VK_PRIOR:
		case '2': mCurrentShader = (mCurrentShader + 1)%mShaders.size();break;
		case '3': if (mStereo3d) mStereo3d = false;else mStereo3d = true;break;

		case 'F': if(mEnableFrustum) mEnableFrustum = false;else mEnableFrustum = true;break;
		case 'C': if(mEnableRefCube) mEnableRefCube = false;else mEnableRefCube = true;break;
		case 'P': if(mEnableParticles) mEnableParticles = false;else mEnableParticles = true;break;
		case ' ': if(mKeyBackground) mKeyBackground = false;else mKeyBackground = true;
			for (int i =0;i<640*480;i++) mMaxDepthBuffer[i] = -10000000;
			break;

		case 'Q':Kinect::Kinect_ColorScaleFactor += 0.0001f;printf("colorscale: %f\n",Kinect::Kinect_ColorScaleFactor ); break;
		case 'A':Kinect::Kinect_ColorScaleFactor -= 0.0001f;printf("colorscale: %f\n",Kinect::Kinect_ColorScaleFactor ); break;

		case 'W':Kinect::Kinect_rgbyoffset += 0.1f;printf("yoff: %f\n",Kinect::Kinect_rgbyoffset ); break;
		case 'S':Kinect::Kinect_rgbyoffset -= 0.1f;printf("yoff: %f\n",Kinect::Kinect_rgbyoffset ); break;

		case 'E':Kinect::Kinect_rgbxoffset += 0.1f;printf("xoff: %f\n",Kinect::Kinect_rgbxoffset ); break;
		case 'D':Kinect::Kinect_rgbxoffset -= 0.1f;printf("xoff: %f\n",Kinect::Kinect_rgbxoffset ); break;


		};
	};

	void ParseDepth()
	{
		mMotorRested++;
		mKinect->ParseDepthBuffer();

		int i =0 ;
		for (int y = 0;y<480;y++)
		{
			unsigned char *destrow = DepthColor + ((479-y)*(640))*3;
			float *destdepth = mDepthBuffer + ((479-y)*(640));
			float *maxdestdepth = mMaxDepthBuffer + ((479-y)*(640));
			unsigned short *bitdepth = mBitDepthBuffer + ((479-y)*(640));
			for (int x = 0;x<640;x++)
			{

				unsigned short Depth = mKinect->mDepthBuffer[i];
				if (Kinect::Kinect_IsDepthValid(Depth))
				{
					*bitdepth ++ = Depth;
					float D = Kinect::Kinect_DepthValueToZ(Depth);
					*destdepth++ = D;
					if (D> *maxdestdepth )
					{
						*maxdestdepth = D;
					}					
					maxdestdepth++;


				}
				else
				{
					*bitdepth++ = -1;
					*destdepth++  = -100000;
					maxdestdepth++ ;
				}
				int pval = mGammaMap[Depth];
				int lb = pval & 0xff;
				switch (pval>>8) 
				{
				case 0:
					destrow[2] = 255;
					destrow[1] = 255-lb;
					destrow[0] = 255-lb;
					break;
				case 1:
					destrow[2] = 255;
					destrow[1] = lb;
					destrow[0] = 0;
					break;
				case 2:
					destrow[2] = 255-lb;
					destrow[1] = 255;
					destrow[0] = 0;
					break;
				case 3:
					destrow[2] = 0;
					destrow[1] = 255;
					destrow[0] = lb;
					break;
				case 4:
					destrow[2] = 0;
					destrow[1] = 255-lb;
					destrow[0] = 255;
					break;
				case 5:
					destrow[2] = 0;
					destrow[1] = 0;
					destrow[0] = 255-lb;
					break;
				default:
					destrow[2] = 0;
					destrow[1] = 0;
					destrow[0] = 0;
					break;
				}

				destrow+=3;
				i++;
			};
		};

	}
	KinectTest(Kinect::Kinect *inK)
	{
		mLastDepthFrameCounter = 0;
		mDepthFrameCounter = 0;
		mKinect = inK;
		for (int i =0;i<640*480;i++) mMaxDepthBuffer[i] = -10000000;
		for (int i=0; i<2048; i++) 
		{	
			mGammaMap[i] = (unsigned short)(float)(powf(i/2048.0f,3)*6*6*256);	
		};
		mMotorPosition = 1.0;
		mLedMode = 0;

	};

	~KinectTest()
	{
		mKinect->RemoveListener(this);
		DestroyGL();
	};

	virtual void KinectDisconnected(Kinect::Kinect *K) 
	{
	};

	virtual void DepthReceived(Kinect::Kinect *K) 
	{
		mDepthFrameCounter++;

		if (W3) InvalidateRect(W3, NULL, false);
	};

	virtual void ColorReceived(Kinect::Kinect *K) 
	{
		mColorFrameCounter++;
	};

};

LRESULT CALLBACK WndProc3( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	KinectTest *KID = 	(KinectTest*)GetWindowLongPtr(hwnd,  GWLP_USERDATA);
	if (KID == NULL)
	{
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	Kinect::Kinect *K = KID->mKinect;

	HDC hdc;
	PAINTSTRUCT ps;
	RECT rect;
	static int w=250, h=150;

	switch(msg)  
	{
	case WM_ERASEBKGND:
		return false;
	case WM_KEYDOWN:
		KID->DoGLChar(wParam);
		break;

	case WM_SIZE:
		GetClientRect(hwnd, &rect);
		w = LOWORD(lParam) + 1;
		h = HIWORD(lParam) + 1;
		InvalidateRect(hwnd, &rect, TRUE);
		break;
	case WM_TIMER:
		InvalidateRect(hwnd, NULL,false);
		KID->mTime += 1/30.0f;
		break;
	case WM_PAINT:
		hdc = BeginPaint(hwnd, &ps);
		{
			RECT R;
			GetClientRect(hwnd, &R);
			int w = R.right-R.left;
			int h = R.bottom - R.top;

			wglMakeCurrent(hdc, KID->mGLContext);
			glViewport(0,0,w,h);
			KID->DrawGL((float)w,(float)h);			
			SwapBuffers( hdc );

		};
		EndPaint(hwnd, &ps);
		break;
	case WM_QUIT:
		DestroyWindow(hwnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}
	return DefWindowProc(hwnd, msg, wParam, lParam);
}

void KinectTest::SetupWindow()
{
	//W= CreateWindowA("edit" , "zephod kinect",WS_VISIBLE| WS_POPUP, 0,0,640,480,NULL,  0,0,0);

	RECT R = {0,0,640,480};
	AdjustWindowRect(&R, WS_OVERLAPPEDWINDOW | WS_VISIBLE, false);
	int Width = R.right - R.left;
	int Height = R.bottom - R.top;


	BITMAPINFO bi;
	ZeroMemory(&bi, sizeof(BITMAPINFO));
	bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
	bi.bmiHeader.biBitCount = 24;
	bi.bmiHeader.biPlanes = 1;

	bi.bmiHeader.biCompression = BI_RGB;
	bi.bmiHeader.biHeight = 480;

	bi.bmiHeader.biWidth = 640;

	WNDCLASS wc3 = {0};
	wc3.lpszClassName = TEXT( "glwindow" );
	wc3.hInstance     = 0 ;
	wc3.hbrBackground = GetSysColorBrush(COLOR_3DFACE);
	wc3.lpfnWndProc   = WndProc3 ;
	wc3.hCursor       = LoadCursor(0, IDC_ARROW);
	RegisterClass(&wc3);


	PIXELFORMATDESCRIPTOR pfd;  
	pfd.cColorBits = pfd.cDepthBits = 32; 
	pfd.dwFlags    = PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;	


	W3 = CreateWindow( wc3.lpszClassName, TEXT("Zephod Kinect Demo - press 3 for 3dmode, PGUP/DN to switch shader, space to switch keying, home/end to zoom, p for particles, cursor to tilt/rotate."), WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		0, Height, Width, Height, NULL, NULL, 0, NULL);  
	SetWindowLongPtr(W3, GWLP_USERDATA, (LONG)this);

	HDC hDC = GetDC ( W3);     
	int PixelFormat = ChoosePixelFormat ( hDC, &pfd) ;
	SetPixelFormat ( hDC, PixelFormat , &pfd );
	mGLContext = wglCreateContext(hDC);
	wglMakeCurrent ( hDC, mGLContext );

	GLeeInit();

	if ((false == GLEE_ARB_shader_objects) || 
		(false == GLEE_ARB_vertex_shader) ||
		(false == GLEE_ARB_fragment_shader)
		//	!GLEE_ARB_texture_non_power_of_two
		)
	{
		DestroyWindow(W3);
		W3 = NULL;
		MessageBox(NULL, L"This demo needs a more advanced video board!", L"error..", MB_OK);		
		exit(0);
	}
	else
	{

		InitGL();

		ReleaseDC(W3, hDC);


		SetTimer(W3, 0,30,NULL);
		ShowWindow(W3, SW_SHOW);
		UpdateWindow(W3);
	};
}


int main(int argc, char **argv)
{



#ifdef SENDOSC 

	int port = 7000;
	std::string target = "127.0.0.1";
	if (argc >2)
	{
		target = argv[1];port  = atoi(argv[2]);
	}
	gTransmitSocket = new UdpTransmitSocket(IpEndpointName(target.c_str(), port));

#endif

	Kinect::KinectFinder KF;
	if (KF.GetKinectCount() < 1)
	{
		printf("Unable to find Kinect devices... Is one connected?\n");
		return 0;
	}

	Kinect::Kinect *K = KF.GetKinect();
	if (K == 0)
	{
		printf("error getting Kinect...\n");
		return 0;
	};

	KinectTest *KT = new KinectTest(K);	
	K->SetMotorPosition(1);
	K->SetLedMode(Kinect::Led_Yellow);
	float x,y,z;
	for (int i =0 ;i<10;i++)
	{
		if (K->GetAcceleroData(&x,&y,&z))
		{
			printf("accelerometer reports: %f,%f,%f\n", x,y,z);
		}
		Sleep(5);
	};
	KT->Run();
	K->SetLedMode(Kinect::Led_Red);
	delete KT;

#ifdef SENDOSC 
	if (gTransmitSocket) delete gTransmitSocket;
#endif

	return 0;
};

void KinectTest::Run()
{
	SetupWindow();
	mKinect->AddListener(this);

	MSG m;

	while (GetMessage(&m, NULL, NULL, NULL))
	{
		TranslateMessage(&m);
		DispatchMessage(&m);
	};
};

void KinectTest::InitGL()
{

	for (int i = 0;i<MAXKEYED;i++)
	{
		mKeyedThings[i] = new SimpleTexture();
	};
	mTopHistogram = new SimpleTexture();
	//	gMainProgram = SetupShaderProgram(::gMainVertexShader, ::gMainPixelShader);

	mCurrentShader = 0;

	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex.txt", "Shaders/Fragment-UnprojectedRGB.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex.txt", "Shaders/Fragment-UV.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex.txt", "Shaders/Fragment-FalseColor.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex.txt", "Shaders/Fragment-Whiz.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex.txt", "Shaders/Fragment-Checker.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex-flat.txt", "Shaders/Fragment-UnprojectedRGB.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex-flat.txt", "Shaders/Fragment-UV.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex-flat.txt", "Shaders/Fragment-FalseColor.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex-flat.txt", "Shaders/Fragment-Whiz.txt"));
	mShaders.push_back(SetupShaderProgramFromFiles("Shaders/Vertex-flat.txt", "Shaders/Fragment-Checker.txt"));
	mEnableParticles = false;
	mEnableRefCube = false;
	mEnableFrustum = false;
	mStereo3d = false;
	mLastParticleAssigned = 0;
	mDistance = 5;

	mColorMode = 1;
	mKeyBackground = false;

	mClearColor.x = 0.2f;
	mClearColor.y = 0.2f;
	mClearColor.z = 0.2f;

	mRenderColor.x = 0;
	mRenderColor.y = 0;
	mRenderColor.z = 0;

	glGenTextures(1, &mColorTexture);
	glGenTextures(1, &mDepthTexture);


	mAvgDownX = 0;
	mAvgDownY = 1;
	mAvgDownZ = 0;

	unsigned char *blankimage = new unsigned char[1024*1024*3];
	for (int i= 0;i<1024*1024;i++)
	{
		int x = (i/32);
		int y = (x/32)/32;
		x%= (1024/32);
		unsigned char check = ((x+y)%2 ==1)?0xff:0;
		blankimage[i*3+0] = check;
		blankimage[i*3+1] = check;
		blankimage[i*3+2] = check;
	};

	glBindTexture( GL_TEXTURE_2D, mColorTexture);
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
	::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 1024, 512, 0,GL_RGB,GL_UNSIGNED_BYTE, blankimage);


	glBindTexture( GL_TEXTURE_2D, mDepthTexture);
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
	::glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, 1024, 512, 0,GL_ALPHA,GL_UNSIGNED_SHORT, blankimage);


	mTime = 0;
	mAngle = -2.3f;
	mTilt = 1;


	int id =0 ;
	for (int y = 0;y<480;y++)
	{
		for (int x = 0;x<640;x++)
		{
			mVertices[id].x = (float)x;
			mVertices[id].y = (float)y;
			mVertices[id].z = (float)sin(id*0.02);
			id++;
		};
	};
	mVBOGrid = new GridVBOSet<Vertex>(640,480, mVertices);
};

void KinectTest::DestroyGL()
{
	if (mVBOGrid) delete mVBOGrid;
};

void KinectTest::RenderFrustum(float x, float y,float z)
{
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glTranslatef(x,y,z);
	Vertex A(0,0,30);
	Vertex B(640,0,30);
	Vertex C(640,480,30);
	Vertex D(0,480,30);
	Vertex E(0,0,2048);
	Vertex F(640,0,2048);
	Vertex G(640,480,2048);
	Vertex H(0,480,2048);
	A.DepthToWorld();
	B.DepthToWorld();
	C.DepthToWorld();
	D.DepthToWorld();
	E.DepthToWorld();
	F.DepthToWorld();
	G.DepthToWorld();
	H.DepthToWorld();

	Vertex *verts[] = {&A,&B,
		&B,&C,
		&C,&D,
		&D,&A,
		&E,&F,
		&F,&G,
		&G,&H,
		&H,&E,
		&A,&E,
		&B,&F,
		&C,&G,
		&D,&H};

	glColor4f(1,1,1,0.3f);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glBegin(GL_LINES);

	for (int i = 0;i<12;i++)
	{
		glVertex3fv(&verts[i*2]->x);
		glVertex3fv(&verts[i*2+1]->x);
	};

	//		float V = (mKeyedFrame[y][x]-69) * (2048/600);

	for (float Z = 20;Z<500;Z+=10)
	{
		float lZ = Z;




		Vertex sA(0,0,lZ);
		Vertex sB(640,0,lZ);
		Vertex sC(640,480,lZ);
		Vertex sD(0,480,lZ);

		sA.DepthToWorld();
		sB.DepthToWorld();
		sC.DepthToWorld();
		sD.DepthToWorld();

		float V = __min(1.0f, (mKeyedHist[::HistogramFromZ<int>(Z)]/150.0));
		glColor4f(V,V,1.0f-V,0.5);
		glVertex3fv(&sA.x);
		glVertex3fv(&sB.x);
		glVertex3fv(&sB.x);
		glVertex3fv(&sC.x);
		glVertex3fv(&sC.x);
		glVertex3fv(&sD.x);
		glVertex3fv(&sD.x);
		glVertex3fv(&sA.x);
	}
	glEnd();
	glPopMatrix();


};


void KinectTest::ActualRender()
{


	// draw a reference cube using red dots
	if (mEnableRefCube)
	{
		glPointSize(3);
		glColor4f(1,0,0,1);
		glBegin(GL_POINTS);
		glVertex3f(-1,-1,-1);
		glVertex3f(1,-1,-1);
		glVertex3f(1,1,-1);
		glVertex3f(-1,1,-1);
		glVertex3f(-1,-1,1);
		glVertex3f(1,-1,1);
		glVertex3f(1,1,1);
		glVertex3f(-1,1,1);
		glEnd();
	};
	//	glEnable(GL_TEXTURE_2D);


	// 1 m = 1 gl unit
	glScalef(0.01f,0.01f,0.01f);
	glDisable(GL_BLEND);
	glPointSize(1);
	glUseProgramObjectARB(mShaders[mCurrentShader]);

	int depthuniform = glGetUniformLocationARB(mShaders[mCurrentShader], "gDepthTexture");
	if (depthuniform>-1)
	{
		glActiveTexture(GL_TEXTURE0 + 0);
		glBindTexture(GL_TEXTURE_2D, mDepthTexture);
		glUniform1iARB(depthuniform, 0);
	};
	int coloruniform = glGetUniformLocationARB(mShaders[mCurrentShader], "gColorTexture");
	if (coloruniform>-1)
	{
		glActiveTexture(GL_TEXTURE0 + 1);
		glBindTexture(GL_TEXTURE_2D, mColorTexture);
		glUniform1iARB(coloruniform, 1);
	};

	mVBOGrid->Render(mActualVertexCount);
	glUseProgramObjectARB(0);

	glActiveTexture(GL_TEXTURE0);

	if (mEnableFrustum)
	{
		RenderFrustum(0,0,0);
	};

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	for (unsigned int i =0 ;i<mFoundContours.size();i++)
	{
		Vertex V1(mFoundContours[i].x,mFoundContoursYExtents[i].x, mFoundContours[i].z );
		Vertex V2(mFoundContours[i].y,mFoundContoursYExtents[i].y, mFoundContours[i].w);

		V1.z = ::ZFromHistogram(V1.z);
		V1.x *= BLOBDIV;
		V1.y *= BLOBDIV;
		V2.z = ::ZFromHistogram(V2.z);
		V2.x *= BLOBDIV;
		V2.y *= BLOBDIV;
		V1.DepthToWorld();
		V2.DepthToWorld();

		glLineWidth(2);
		if (mRenderFoundContours[i])
		{
			glColor4f(0,1,0,0.4);

			glBegin(GL_LINES);
			glVertex3f(V1.x,V1.y, V1.z);
			glVertex3f(V1.x,V2.y, V1.z);
			glVertex3f(V1.x,V1.y, V2.z);
			glVertex3f(V1.x,V2.y, V2.z);
			glVertex3f(V2.x,V1.y, V1.z);
			glVertex3f(V2.x,V2.y, V1.z);
			glVertex3f(V2.x,V1.y, V2.z);
			glVertex3f(V2.x,V2.y, V2.z);

			glVertex3f(V1.x,V2.y, V2.z);
			glVertex3f(V2.x,V2.y, V2.z);

			glVertex3f(V1.x,V2.y, V1.z);
			glVertex3f(V2.x,V2.y, V1.z);

			glVertex3f(V1.x,V2.y, V1.z);
			glVertex3f(V1.x,V2.y, V2.z);

			glVertex3f(V2.x,V2.y, V1.z);
			glVertex3f(V2.x,V2.y, V2.z);

			glVertex3f(V1.x,V1.y, V2.z);
			glVertex3f(V2.x,V1.y, V2.z);

			glVertex3f(V1.x,V1.y, V1.z);
			glVertex3f(V2.x,V1.y, V1.z);

			glVertex3f(V1.x,V1.y, V1.z);
			glVertex3f(V1.x,V1.y, V2.z);

			glVertex3f(V2.x,V1.y, V1.z);
			glVertex3f(V2.x,V1.y, V2.z);

			glEnd();
		};
	};

	if (mEnableParticles)
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		//glDisable(GL_DEPTH_TEST);
		glPointSize(8);
		glBegin(GL_POINTS);
		for (int i = 0;i<MAXPARTICLE;i++)
		{
			if (mParticles[i].mActive) 
			{
				mParticles[i].Update(0.15f);
				mParticles[i].Render();
			};
		};
		glEnd();
		glEnable(GL_DEPTH_TEST);
	};
#ifdef SENDOSC
	glPointSize(10);
	glColor4f(1,1,0,1);
	glDisable(GL_DEPTH_TEST);
	glBegin(GL_POINTS);
	for (unsigned int i = 0 ;i<mBlobs.size();i++)
	{
		Vertex B(mBlobs[i].center.x, mBlobs[i].center.y, mBFrame[mBlobs[i].center.y][mBlobs[i].center.x]);
		B.x *= BLOBDIV;
		B.y *= BLOBDIV;
		B.DepthToWorld();

		glVertex3fv(&B.x);
	};
	glEnd();
	glEnable(GL_DEPTH_TEST);
#endif

};


void KinectTest::DrawGL(float w, float h)
{



	if (mDepthFrameCounter!=mLastDepthFrameCounter)
	{
		mLastDepthFrameCounter = mDepthFrameCounter;
		ParseDepth();
		glBindTexture(GL_TEXTURE_2D, mDepthTexture);
		::glTexSubImage2D(GL_TEXTURE_2D, 0,0,0,640,480, GL_ALPHA,GL_UNSIGNED_SHORT, mKinect->mDepthBuffer);
	};
	if (mColorFrameCounter!=mLastColorFrameCounter)
	{
		mKinect->ParseColorBuffer();
		mLastColorFrameCounter = mColorFrameCounter;
		glBindTexture(GL_TEXTURE_2D, mColorTexture);
		::glTexSubImage2D(GL_TEXTURE_2D, 0,0,0,640,480, GL_RGB,GL_UNSIGNED_BYTE, mKinect->mColorBuffer);

		for (int y  = 0;y<480;y+=BLOBDIV)
		{

			for (int x  = 0;x<640;x+=BLOBDIV)
			{
				int yy = y/BLOBDIV;
				int xx = x/BLOBDIV;
				mBFrame[yy][xx] = mDepthBuffer[(x+y*640)];
				if (mBFrame[yy][xx] < mMaxDepthBuffer[(x+y*640)]-50)
				{
					mKeyedFrame[yy][xx] = mDepthBuffer[(x+y*640)];
				}
				else
				{
					mKeyedFrame[yy][xx] = 0;
				}
				if (mEnableParticles)
				{
					if (mBFrame[yy][xx]>-90000)
					{
						mDFrame[yy][xx] = mBFrame[yy][xx]-mOldBFrame[yy][xx]; 

						if (mDFrame[yy][xx]<-40 && (rand()%100)<50)
						{
							int P = 0;
							while (P<MAXPARTICLE)
							{
								int idx = (P + mLastParticleAssigned) %MAXPARTICLE;
								if (mParticles[idx].mActive == false)
								{
									mParticles[idx].Reset();
									mParticles[idx].mActive = true;
									mParticles[idx].mPosition.x = (float)x;
									mParticles[idx].mPosition.y = (float)y;
									mParticles[idx].mPosition.z = mBFrame[yy][xx];
									mParticles[idx].mPosition.DepthToWorld();
									mLastParticleAssigned = idx;
									break;
								}
								P++;
							};
						};
					};
				};
			};
		};
		ZeroMemory(mKeyedHist, sizeof(mKeyedHist));
		ZeroMemory(mTopHist, sizeof(mTopHist));
		float min = 100000;
		float max = -100000;
		for (int y  = 0;y<BLOBH;y++)
		{

			for (int x  = 0;x<BLOBW;x++)
			{
				if (mKeyedFrame[y][x]>0)
				{
					float V = HistogramFromZ<float>(mKeyedFrame[y][x]);
					if (V<min) min = V;
					if (V>max) max = V;
					mKeyedHist[(int)__max(0, __min((HISTLEN), V))]++;
					mTopHist[x][(int)__max(0, __min((HISTLEN), V))]++;
				};
			}
		};
		int peak1 = -1;
		int peakval = 0;
		int peak2 = -1;
		for (int x =0;x<HISTLEN;x++)
		{
			if (mKeyedHist[x]>peakval)
			{
				peak2 = peak1;
				peak1 = x;
				peakval = mKeyedHist[x];
			};
		};


		float DH = 0;
		float DDH = 0;
		float LH = 0;
		float runningval = 0;
		float runningdelta = 0;

		mKeyedHistRanges.clear();

		for (int x =0;x<HISTLEN;x++)
		{
			float Cur =mKeyedHist[x];
			float Delta = (Cur-runningval)/5;
			runningval += Delta;
			runningdelta += (Delta-runningdelta)/5;
			mKeyedHistD1[x] = runningval;
			float NDH = Cur-LH;
			DDH = DH-NDH;
			mKeyedHistD2[x] = runningdelta;
			DH = NDH;
			LH = Cur;
		};

		DH = 0;
		DDH = 0;
		LH = 0;
		runningval = 0;
		runningdelta = 0;


		for (int x =(HISTLEN )-1;x>-1;x--)
		{
			float Cur =mKeyedHist[x];
			float Delta = (Cur-runningval)/5;
			runningval += Delta;
			runningdelta += (Delta-runningdelta)/5;
			mKeyedHistD1[x] += runningval;
			float NDH = Cur-LH;
			DDH = DH-NDH;
			mKeyedHistD2[x] += runningdelta;
			DH = NDH;
			LH = Cur;
		};

		Kinect::V2i CurrentRange;
		CurrentRange.x = -1;
		CurrentRange.y =-1; 
		float T = 20;
		for (int x =0;x<HISTLEN;x++)
		{
			if (mKeyedHistD2[x] >= T)
			{
				if (CurrentRange.x < 0) CurrentRange.x = x;
				CurrentRange.y = x;
			}
			else
			{
				if (CurrentRange.x > -1)
				{
					mKeyedHistRanges.push_back(CurrentRange);
					CurrentRange.x = -1;
				};
			};

		};
		if (CurrentRange.x > -1)
		{
			mKeyedHistRanges.push_back(CurrentRange);
			CurrentRange.x = -1;
		};


		CalculateTopHistogram();
		CalculateContours();

		memcpy(mOldBFrame, mBFrame, (640/BLOBDIV)*(480/BLOBDIV)*sizeof(float));

#ifdef SENDOSC 



		::BlobSpace::BlobFrame F ;
		F.imageData = &mBFrame[0][0];
		F.height = 480/BLOBDIV;
		F.width = 640/BLOBDIV;
		mBlobs.clear();
		BlobSpace::DetectBlobs(&F, &mBlobs);
		char buffer[4000];
		osc::OutboundPacketStream p( buffer, 4000 );
		p << osc::BeginBundleImmediate << osc::BeginMessage( "/blobstart" )<<osc::EndMessage;
		//		p << osc::BeginMessage( "/blob" ) << 10.0 << 10.0<< osc::EndMessage;

		for (unsigned int i =0;i<mBlobs.size();i++)
		{


			float Z = 0;
			int count  = 0;
			if (mBlobs[i].size>5*5)
			{
				int ext = 1; 
				for (int x = __max(mBlobs[i].center.x - ext, 0);x<__min(640/BLOBDIV-1, mBlobs[i].center.x + ext);x++)
				{
					for (int y = __max(mBlobs[i].center.y - ext, 0);y<__min(480/BLOBDIV-1, mBlobs[i].center.y + ext);y++)
					{
						if (mBFrame[y][x]>-100000)
						{
							count++;
							Z += mBFrame[y][x];
						};
					};
				};
				if (count > 0) Z /= (float)count;


				p << osc::BeginMessage( "/blob" )<< (int)i << (float)mBlobs[i].center.x << (float)mBlobs[i].center.y << Z << (float)mBlobs[i].size <<osc::EndMessage;
			};
		}
		p << osc::BeginMessage( "/blobend" )<<osc::EndMessage << osc::EndBundle;
		gTransmitSocket->Send( p.Data(), p.Size() );

#endif


		int id =0;


		int idx = 0;
		for (int y  = 0;y<480;y++)
		{
			for (int x  = 0;x<640;x++)
			{

				float zz = mDepthBuffer[idx];
				bool skip = false;
				if (mKeyBackground && zz >= mMaxDepthBuffer[idx]-50)
				{
					skip = true;
				};
				if (zz>-90000 && !skip)
				{

					mVertices[id].x = (float)x;
					mVertices[id].y = (float)y;
					mVertices[id].z = zz;

					//				Kinect::KinectDepthToWorld(mVertices[id].x,mVertices[id].y,mVertices[id].z);

					//	glVertex3f(xx,yy,zz);

					id++;
				};
				idx ++;
			};
		};
		//	glEnd();



		mActualVertexCount = id;
		mVBOGrid->Upload(mVertices, mActualVertexCount);
	};



	// clear to black
	switch (mColorMode)
	{
	default:
		glClearColor(0,0,0,1);
		break;
	case 2:
		glClearColor(mClearColor.x,mClearColor.y,mClearColor.z,1);
		break;
	};
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


	glEnable(GL_DEPTH_TEST);

	// define camera properties
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	::gluPerspective(30,w/h, 0.05, 1000);

	// set up the camera position
	if (mStereo3d)
	{
		glColorMask(true,false,false, true);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		gluLookAt(sin(mAngle*0.2)*mDistance,mTilt,cos(mAngle*0.2)*mDistance,0,0,0,0,1,0);
		glPushMatrix();
		ActualRender();
		glPopMatrix();
		glClear(GL_DEPTH_BUFFER_BIT);
		glColorMask(false,true,true, true);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatef(0.02,0,0);
		gluLookAt(sin(mAngle*0.2)*mDistance,mTilt,cos(mAngle*0.2)*mDistance,0,0,0,0,1,0);

		glPushMatrix();
		ActualRender();
		glPopMatrix();

		glColorMask(true,true,true, true);
	}
	else
	{
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		gluLookAt(sin(mAngle*0.2)*mDistance,mTilt,cos(mAngle*0.2)*mDistance,0,0,0,0,1,0);
		glPushMatrix();
		ActualRender();
		glPopMatrix();
	};

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	::gluOrtho2D(0,w,h,0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glDisable(GL_DEPTH_TEST);
	float SquareX = 4;
	float SquareY = 4;
	float SquareW = w/8.0f;
	float SquareH = SquareW * (480.0f/640.0f);
	if (1)
	{
		glLineWidth(3);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);
		glBegin(GL_LINES);
		for(int x = 0;x<HISTLEN;x++)
		{
			float fx = x*w/(2048.0f/HISTDIV);
			float V = mKeyedHist[x]*0.3;
			glColor4f(1,0,0,1);
			glVertex2f(fx, h);
			glVertex2f(fx, h-V);
			glColor4f(1,1,0,1);
			float V2 = mKeyedHistD1[x]*0.3;
			fx+=3;
			glVertex2f(fx, h);
			glVertex2f(fx, h-V2);
			float V3 = mKeyedHistD2[x]*0.5;
			fx+=3;
			glColor4f(0,0,1,1);
			glVertex2f(fx, h);
			glVertex2f(fx, h-V3);

		};

		for (int i = 0;i<mKeyedHistRanges.size();i++)
		{
			glColor4f(1,1,1,1);
			float fx1 = (mKeyedHistRanges[i].x*w)/(2048.0f/HISTDIV);
			float fx2 = (mKeyedHistRanges[i].y*w)/(2048.0f/HISTDIV);
			glVertex2f(fx1, h-50);
			glVertex2f(fx2, h-50);
			glVertex2f(fx1, h-54);
			glVertex2f(fx2, h-53);
		};

		glEnd();

		glEnable(GL_TEXTURE_2D);
	
		{
			mTopHistogram->Bind();

			float fx1 = w - BLOBW*2-10;
			float fx2 = fx1+BLOBW*1;

			float fh = 4; 
			glColor4f(1,1,1,1);
			glBegin(GL_QUADS);
			glTexCoord2f(0         ,(HISTLEN)/512.);glVertex2f(fx1, fh);
			glTexCoord2f(BLOBW/512.,(HISTLEN)/512.);glVertex2f(fx2, fh);
			glTexCoord2f(BLOBW/512.,0);glVertex2f(fx2, fh+(HISTLEN*2));
			glTexCoord2f(0         ,0);glVertex2f(fx1, fh+(HISTLEN*2));
			glEnd();
		}

		int activetex = 0;
		for (int i =0 ;i<this->mRenderFoundContours.size() && activetex < MAXKEYED;i++)
		{

			if (mRenderFoundContours[i])
			{
				mKeyedThings[activetex]->Bind();
				glColor4f(1,1,1,0.5f);
				glEnable(GL_BLEND);
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glColor4f(1,1,1,1);
				float fx1 = w - BLOBW-5;
				float fx2 = w-5;
				float fh = activetex *(BLOBH+4) + 4; 
				glBegin(GL_QUADS);
				glTexCoord2f(0         ,BLOBH/512.);glVertex2f(fx1, fh);
				glTexCoord2f(BLOBW/512.,BLOBH/512.);glVertex2f(fx2, fh);
				glTexCoord2f(BLOBW/512.,0);glVertex2f(fx2, fh+BLOBH);
				glTexCoord2f(0         ,0);glVertex2f(fx1, fh+BLOBH);
				glEnd();
				activetex++;
			};
		};


		glBindTexture(GL_TEXTURE_2D, mColorTexture);
		glEnable(GL_TEXTURE_2D);
		glColor4f(1,1,1,0.5f);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		float tx = (640.0f/1024.0f);
		float ty2 = (480.0f/512.0f);
		float ty = (0/512);
		glBegin(GL_QUADS);
		glTexCoord2f(0 ,ty);glVertex2f(SquareX, SquareY);
		glTexCoord2f(tx,ty);glVertex2f(SquareX + SquareW,SquareY);
		glTexCoord2f(tx,ty2);glVertex2f(SquareX+SquareW,SquareY+ SquareH);
		glTexCoord2f(0 ,ty2);glVertex2f(SquareX,SquareY+ SquareH);
		glEnd();

		SquareX += SquareW + 4;

		glBindTexture(GL_TEXTURE_2D, mDepthTexture);
		glBegin(GL_QUADS);
		glTexCoord2f(0 ,ty);glVertex2f(SquareX, SquareY);
		glTexCoord2f(tx,ty);glVertex2f(SquareX + SquareW,SquareY);
		glTexCoord2f(tx,ty2);glVertex2f(SquareX+SquareW,SquareY+ SquareH);
		glTexCoord2f(0 ,ty2);glVertex2f(SquareX,SquareY+ SquareH);
		glEnd();

		
	};
	glDisable(GL_TEXTURE_2D);
}

void KinectTest::DoGLChar(unsigned short KeyCode)
{
	switch (KeyCode)
	{
	case VK_LEFT:
		mAngle += 0.1f;
		break;
	case VK_RIGHT:
		mAngle -= 0.1f;
		break;
	case VK_UP:
		mTilt += 0.1f;
		break;
	case VK_DOWN:
		mTilt -= 0.1f;
		break;
	default:
		DoChar(KeyCode);
		break;
	};
};

